package com.example.android_2026_m12;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;


import java.util.Arrays;

import java.util.Random;



    public class MainActivity extends AppCompatActivity {

        private static final String TAG = "finaletiqueta";

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            int size = 1_000_000;
            int[] enteros = new int[size];
            Random arraleatorio = new Random();

            for (int i = 0; i < size; i++) {
                enteros[i] = arraleatorio.nextInt();
            }

            long inicio = System.currentTimeMillis();
            Arrays.sort(enteros);
            long finalT = System.currentTimeMillis();
            for (int i = 0; i < 10; i++) {
                Log.d(TAG, "Elemento " + i + ": " + enteros[i]);
            }

            long duracion = finalT - inicio;
            Log.d(TAG, "Tiempo " + duracion + " ms");
        }
    }

